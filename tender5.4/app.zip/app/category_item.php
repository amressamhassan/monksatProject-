<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class category_item extends Model
{
    public $table = "category_item";
    public $timestamps = false;


}
