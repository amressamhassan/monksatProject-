<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class seen extends Model
{
    public $table = "seen";

}
