<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class users_type extends Model
{
    //
}
