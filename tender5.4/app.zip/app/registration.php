<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registration extends Model
{
    //
}
