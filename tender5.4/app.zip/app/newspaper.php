<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class newspaper extends Model
{

    protected $table='newspaper';
    public $timestamps = false;

}
