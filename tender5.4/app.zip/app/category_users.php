<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class category_users extends Model
{
    public $table = "category_users";
    public $timestamps = false;


}
